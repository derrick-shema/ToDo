import 'package:flutter/material.dart';
import 'package:to_do_app/pages/new_task_page.dart';
import 'package:to_do_app/services/my_controller.dart';

import '../model/task.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _tasks = MyController.getTasks();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.separated(
        itemBuilder: (_, index) {
          return _toWidget(_tasks[index]);
        },
        separatorBuilder: (_, __) => Divider(),
        itemCount: _tasks.length,
      ),
      appBar: AppBar(title: Text('Todo')),
      floatingActionButton: FloatingActionButton (
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NewTaskPage())
          );
        },
      ),
    );
  }

  Widget _toWidget(Task t) {
    //return Container();
    return CheckboxListTile(
        value: t.isCompleted,
        onChanged: (newValue) {
          setState(() {
            t.isCompleted = newValue ?? false;
          });
        },
      title: Text(t.description),
    );
  }
}
