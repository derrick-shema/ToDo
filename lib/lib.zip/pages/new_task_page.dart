import 'package:flutter/material.dart';

class NewTaskPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add New Task')),
      body: ListView(
        children: [
          const TextField(
            decoration: InputDecoration(labelText: 'New task'),
            minLines: 3,
            maxLines: null,
          ),
          ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Save'))
        ],
      ),
    );
  }
}
